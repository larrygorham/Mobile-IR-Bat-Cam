//  gcc led23.c -o led23 -lwiringPi


#include <wiringPi.h>



int main() {

    int ledPin = 23; // GPIO pin connected to LED (modify as needed)



    wiringPiSetup(); // Initialize wiringPi

    pinMode(ledPin, OUTPUT); // Set LED pin as output

while(1){

    digitalWrite(ledPin, HIGH); // Turn LED on
    sleep(1);

    digitalWrite(ledPin, LOW); // Turn LED off
    sleep(1);    



    return 0;

} 
