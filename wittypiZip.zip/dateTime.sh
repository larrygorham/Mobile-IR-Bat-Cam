#!/bin/bash

while true
do
	date +"%D %H %M %S"
	sleep 1
done



