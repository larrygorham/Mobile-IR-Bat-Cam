#!/bin/bash

sudo chown larry:larry /home/larry/wittypi/schedule.wpi

filename_list="/home/larry/wittypi/runList.txt"
filename_settings="/home/larry/wittypi/runSettings.txt"
filename_schedule="/home/larry/wittypi/schedule.wpi"
filename_times="/home/larry/wittypi/beginTimes.txt"

currentTime=$(date +%s)
beforeCurrent=67
afterCurrent=30
bootTime=40
extraTime=10
#  Get total number of runs and runLength
nRuns=$(eval $(echo head -1 $filename_settings) | tail -1)
#   Get the runNumber
xRunN=$(cat /home/larry/wittypi/runNumber.txt)
runLength=$(eval $(echo head -2 $filename_settings) | tail -1)	
runTime=$(eval $(echo head -$xRunN $filename_times) | tail -1)
while [ $runTime -le $currentTime ] 
do
	let xRunN++;echo $xRunN > /home/larry/wittypi/runNumber.txt
	runTime=$(eval $(echo head -$xRunN $filename_times) | tail -1)
	#printf "$xRunN  runTime: $runTime currentTime: $currentTime\n"    >> /home/larry/wittypi/run.txt
done
printf "$xRunN  runTime: $runTime currentTime: $currentTime\n"    >> /home/larry/wittypi/run.txt
nextRunTime=$(eval $(echo head -$((xRunN+1)) $filename_times) | tail -1)
#   Get the runNumber
xRunN=$(cat /home/larry/wittypi/runNumber.txt)
printf "runLength sec $runLength\n"    >> /home/larry/wittypi/run.txt
printf " nRuns:  $nRuns\n"    >> /home/larry/wittypi/run.txt

printf "currentTime $(date -d @"$currentTime" "+%Y-%m-%d %H:%M:%S")\n"    >> /home/larry/wittypi/run.txt
printf "xRunN:  $xRunN\n"    >> /home/larry/wittypi/run.txt
printf "beforeCurrent:  $beforeCurrent  "    >> /home/larry/wittypi/run.txt
printf "  afterCurrent:  $afterCurrent\n"    >> /home/larry/wittypi/run.txt
printf "bootTime:  $bootTime  "    >> /home/larry/wittypi/run.txt
printf "  extraTime:  $extraTime\n"    >> /home/larry/wittypi/run.txt

if [ $xRunN -ne $nRuns ]; then
	if [ $xRunN -eq 1 ]; then
		#   Get starttime in unix form
		beginTime=$((currentTime-beforeCurrent))
		endTime=$((runTime+runLength+extraTime))
		onTime=$((beforeCurrent+afterCurrent))
		offTime=$((runTime-currentTime-afterCurrent-bootTime - 15))
	else 
		beginTime=$((currentTime-beforeCurrent))
		endTime=$((runTime+runLength+extraTime))
		onTime=$((beforeCurrent+afterCurrent))
		offTime=$((runTime-currentTime-afterCurrent-bootTime))
	fi
		printf "runTime $(date -d @"$runTime" "+%Y-%m-%d %H:%M:%S")\n"    >> /home/larry/wittypi/run.txt
		printf "offTime sec $offTime\n"    >> /home/larry/wittypi/run.txt

		printf "BEGIN        $(date -d @"$beginTime" "+%Y-%m-%d %H:%M:%S")\n"  >> /home/larry/wittypi/run.txt
		printf "END          $(date -d @"$endTime" "+%Y-%m-%d %H:%M:%S")\n\n"  >> /home/larry/wittypi/run.txt
		#printf "END          2025-03-06 23:30:37\n\n"    >> /home/larry/wittypi/run.txt
		
		printf "ON       S$onTime\n"    >> /home/larry/wittypi/run.txt
		printf "OFF      S$offTime\n"    >> /home/larry/wittypi/run.txt

		printf "BEGIN        $(date -d @"$beginTime" "+%Y-%m-%d %H:%M:%S")\n" > /home/larry/wittypi/schedule.wpi
		printf "END          $(date -d @"$endTime" "+%Y-%m-%d %H:%M:%S")\n\n" >> /home/larry/wittypi/schedule.wpi
		#printf "END          2025-03-06 19:30:37\n\n"    >> /home/larry/wittypi/schedule.wpi
		printf "ON       S$onTime\n"     >> /home/larry/wittypi/schedule.wpi
		printf "OFF      S$offTime\n"  >> /home/larry/wittypi/schedule.wpi
			#   increment runNumber
		let xRunN++;echo $xRunN > /home/larry/wittypi/runNumber.txt
		. /home/larry/wittypi/runScript.sh
else
 	echo 1 > /home/larry/wittypi/runNumber.txt
	. /home/larry/kl
fi
printf "\n"	 
	

# current_time=$(date +%s)
# formatted_date=$(date -d @"$current_time" "+%Y-%m-%d %H:%M:%S")
# echo "Formatted date: $formatted_date"

# date "+%Y-%m-%d %H:%M:%S"
# printf "Name: %s\nAge: %d\nCity: %s\n" "$name" "$age" "$city" > test.txt
