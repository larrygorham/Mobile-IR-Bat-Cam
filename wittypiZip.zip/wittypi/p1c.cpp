// g++ p1.cpp -o p1 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <cstdlib>

#include <iostream>
#include <time.h>


#define MAX_TIMES  100
#define MAX_LINE_LENGTH  256


//#define schedulesFile.txt  "beginEndTimes.txt"  



using namespace std;
//----------------------------------------------------------------------------------------------
void getWMCCform(char tempWMCCform[30], const time_t &now)
{
    struct tm *timeinfo;
	
	//timeinfo = localtime(&now);

    char buffer[80];


    // Format date and time (e.g., "20250124_214100")
    strftime(buffer, sizeof(buffer), "%Y%m%d_%H%M%S", timeinfo);

    // Create timeForm with date and time
    strcpy(tempWMCCform, "WMCC_SKED_");
    strcat(tempWMCCform, buffer);
    strcat(tempWMCCform, ".txt");

	return ;
}

int main() {

    char times[MAX_TIMES][MAX_LINE_LENGTH];
    FILE *timesFile;
    FILE *fp;
    FILE *runListFile;

    int nRuns;         // 2
    int lineCount;
    int videoLength;  // 60   seconds
    int gapLength;  //   120  Seconds
   // Reading from timesFile

     fp = fopen("runSettings.txt", "r");
    if (fp == NULL) {
        printf("Error opening timesFile for reading!\n");
        return 1;
    }

    fscanf(fp, "%d\n", &nRuns);
    fscanf(fp, "%d\n", &videoLength);
    fscanf(fp, "%d", &gapLength);
    fclose(fp);
    printf("Number runs %d\n", nRuns);
    printf("Video Length in seconds: %d\n", videoLength);
    printf("seconds between runs: %d\n", gapLength);
    
    timesFile = fopen("beginEndTimes.txt", "r");
    if (timesFile == NULL) {
        printf("Error opening timesFile.\n");
        return 1;
    }

    // Read each line from the timesFile and store it in the array
    while (fgets(times[lineCount], MAX_LINE_LENGTH, timesFile) != NULL && lineCount < MAX_TIMES) {
        lineCount++;
    }

    fclose(timesFile);

    // Print the times read from the timesFile
    printf("times read from the degineEndTimes.txt:\n");
    for (int i = 0; i < lineCount; i++) {
        printf("%s", times[i]);
    }
    
    runListFile = fopen("runList.txt", "r");
    // Establish each run file name for the runList.txt 
        printf("times read from the degineEndTimes.txt:\n");
    for (int i = 0; i < lineCount; i+=2) {
        printf("%s", times[i]);
    }
    
    

    return 0;
}
