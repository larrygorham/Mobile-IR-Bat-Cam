// g++ readNameOpen.cpp -o readNameOpen
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <cstdlib> // for system()

int main() {
    std::string command = "cat runList.txt"; // List all .txt files in current directory (Linux/macOS)


    FILE* skedFile = popen(command.c_str(), "r");
    if (!skedFile) {
        std::cerr << "Error opening skedFile." << std::endl;
        return 1;
    }

    char buffer[256];
    std::vector<std::string> filenames;
    while (fgets(buffer, sizeof(buffer), skedFile) != nullptr) {
        filenames.push_back(std::string(buffer, strlen(buffer) - 1)); // Remove trailing newline
    }

    pclose(skedFile);
    int fi = 0;
    int onTest = 3 ;
    int offTest = 5; 
    // Open each file
    for (const auto& filename : filenames) {
        std::ofstream file(filename);  //To read use:   std::ifstream file(filename); 
        if (file.is_open()) {
            // Process the file
            std::cout << "Opened file: " << filename << std::endl;
            // ... Write contents of the file
            file << "   ON  S"  << onTest << "\n";
            file.close();
            fi++;
        } else {
            std::cerr << "Error opening file: " << filename << std::endl;
        }
    }

    return 0;
}
