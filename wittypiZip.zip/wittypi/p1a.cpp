// g++ p1.cpp -o p1 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINES 100
#define MAX_LINE_LENGTH 256
#define filename "beginEndTimes.txt"

int main() {
    //char filename[256];
    char lines[MAX_LINES][MAX_LINE_LENGTH];
    FILE *file;
    int lineCount = 0;
    int videoLength = 60;  //seconds
    int gapLength = 120;  //Seconds
    //printf("Enter the filename: ");
    //scanf("%s", filename);
    //strcat(filename,"beginEndTimes.txt");

    file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    // Read each line from the file and store it in the array
    while (fgets(lines[lineCount], MAX_LINE_LENGTH, file) != NULL && lineCount < MAX_LINES) {
        lineCount++;
    }

    fclose(file);

    // Print the lines read from the file
    printf("Lines read from the file:\n");
    for (int i = 0; i < lineCount; i++) {
        printf("%s", lines[i]);
    }

    return 0;
}
