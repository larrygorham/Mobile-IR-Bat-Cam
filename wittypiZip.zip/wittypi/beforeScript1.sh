#!/bin/bash
# file: beforeScript.sh
#
# This script will run after Raspberry Pi boot up, and before running the schedule script.
# If you want to change the schedule script before running it, you may do so here.
#
#       record video


exec /home/larry/raspberry-pi-opencv/twoCore/fps
exec /home/larry/wittypi/loadSked.sh
