/*
 *  getFileName.c:
 *  
 *
 

sudo gcc getFileName.c -o getFileName
 ***********************************************************************
 */
#include <stdio.h>
#include <time.h>
#include <string.h>


//----------------------------------------------------------------------------------------------
void getFileName(char tempFileName[14], int tempOld)
{
	//**  This  converts current int time to char time into seconds
        int numbers[] = {'0','1', '2', '3', '4', '5','6','7','8','9'};
	char seconds[10]; //Time in seconds
	int j,temp; //Used in conversion

	for(j=0; j <= 9; j++)
		{
		temp = (int)(tempOld/10.);
		seconds[9-j] = numbers[tempOld - temp*10];
		tempOld = temp;
		}
	sprintf (tempFileName, "%.10s.txt", seconds); // Attach the suffix	
	return ;
}

//************************************************** MAIN **************************
void main (){
	
char* cur_t_string;
time_t cur_time;
int logStartTime = 0;

FILE *log_file;


char fileName[14];
 //  ******************************************
		cur_t_string = ctime(&cur_time); //convert to local time format
		printf("%d  %s \n",cur_time, cur_t_string);
		getFileName(fileName,cur_time);
		printf("File name %s \n", fileName);
		logStartTime = cur_time;
		log_file =fopen(fileName, "w");
		

	log_file =fopen(fileName, "a");


	fprintf(log_file,"Hello wsorld\n");

	fclose(log_file); 
}


