#!/bin/bash

./p0
slwwp 1
./p1
sleep 1
./p2
