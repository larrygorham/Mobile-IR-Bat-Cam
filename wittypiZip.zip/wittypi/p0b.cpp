// g++ p0.cpp -o p0 
#include <stdio.h>
#include <cstdlib>

#include <iostream>
#include <time.h>
#include <string.h>


using namespace std;
//----------------------------------------------------------------------------------------------
void getTimeForm(char temptimeForm[30], const time_t &now)
{
    struct tm *timeinfo;
	
	timeinfo = localtime(&now);

    char buffer[80];


    // Format date and time (e.g., "2025-01-24 21:41:00")
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", timeinfo);

    // Create timeForm with date and time
    //strcpy(temptimeForm, "WMCC_MYLU_");
    strcat(temptimeForm, buffer);
    //strcat(temptimeForm, ".txt");

	return ;
}

int main() {
    
    time_t now;
    time_t nowPlus;
    struct tm *timeinfo;
    char timeForm[100];
    int nRuns;
    int videoLength;  //seconds
    int gapLength;  //Seconds
    int runNum;
    FILE *fp;

   // Reading from file

    fp = fopen("runSettings.txt", "r");
    if (fp == NULL) {
        printf("Error opening file for reading!\n");
        return 1;
    }

    fscanf(fp, "%d\n", &nRuns);
    fscanf(fp, "%d\n", &videoLength);
    fscanf(fp, "%d", &gapLength);
    fclose(fp);
    printf("Number runs %d\n", nRuns);
    printf("Video Length in seconds: %d\n", videoLength);
    printf("seconds between runs: %d\n", gapLength);
    
    fp = fopen("runTimes.txt", "w");
    if (fp == NULL) {
        printf("Error opening file for writing!\n");
        return 1;
    }    

    // Get current time
    time(&now);
	//const long int intNow = now;
	//printf("time now  %d\n",intNow);
    nowPlus = now + gapLength;
	getTimeForm(timeForm,nowPlus);
    printf("First run time: %s\n", timeForm);
    fprintf(fp, "%s\n", timeForm);
    fclose(fp);
    now = nowPlus;
    fp = fopen("runTimes.txt", "a");
    for (int runN = 2; runN <= nRuns; runN++){
        memset(timeForm,0,strlen(timeForm)); 
        nowPlus = now + videoLength + gapLength;
        getTimeForm(timeForm,nowPlus);
        printf("run%d time: %s\n", runN, timeForm);

        // Writing to file


        fprintf(fp, "%s\n", timeForm);
        now = nowPlus;
    
    }
    
    fclose(fp);





    return 0;
}
