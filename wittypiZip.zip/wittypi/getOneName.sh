#!/bin/bash

filename_list="/home/larry/wittypi/runList.txt"

xRunN=$(cat /home/larry/wittypi/runNumber.txt)
filename=$(eval $(echo head -$xRunN $filename_list) | tail -1)
echo $filename

