#!/bin/bash

# Check if a filename is provided as an argument
#if [ $# -eq 0 ]; then
#  echo "Usage: $0 <file_containing_filenames>"
#  exit 1
#fi

# Assign the filename provided as an argument to a variable
#filename_list="$1"
filename_list="runList.txt"

# Check if the file containing the filenames exists
if [ ! -f "$filename_list" ]; then
  echo "File not found: $filename_list"
  exit 1
fi

# Read each line from the file containing filenames
while read -r filename; do
  # Check if the file exists
  if [ -f "$filename" ]; then
    echo "File found: $filename"
    # Do something with the file (e.g., cat, ls, etc.)
  else
    echo "File not found: $filename"
  fi
done < "$filename_list"
