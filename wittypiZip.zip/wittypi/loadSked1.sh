#!/bin/bash

filename_list="/home/larry/wittypi/runList.txt"
filename_settings="/home/larry/wittypi/runSettings.txt"
filename_schedule="/home/larry/wittypi/schedule.wpi"

#  Get total number of runs
nRuns=$(eval $(echo head -1 $filename_settings) | tail -1)
#   Get the runNumber
xRunN=$(cat /home/larry/wittypi/runNumber.txt)

if [ $((nRuns  - xRunN + 1 )) == 0 ]; then
	echo 1 > /home/larry/wittypi/runNumber.txt
	sudo cp /home/larry/wittypi/del.wpi  $filename_schedule	
	sudo ./home/larry/kl
else	
	filename=$(eval $(echo head -$xRunN $filename_list) | tail -1)
	echo $filename
	sudo cp $filename  $filename_schedule
	#   increment runNumber
	let xRunN++;echo $xRunN > /home/larry/wittypi/runNumber.txt
fi

#eval /home/larry/wittypi/runScript.sh


