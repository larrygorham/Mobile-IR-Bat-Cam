#!/bin/bash

filename_list="/home/larry/wittypi/runList.txt"

#   Get the runNumber
xRunN=$(cat /home/larry/wittypi/runNumber.txt)
filename=$(eval $(echo head -$xRunN $filename_list) | tail -1)
echo $filename
sudo cp $filename  /home/larry/wittypi/schedule.wpi
#   increment runNumber
let xRunN++;echo $xRunN > /home/larry/wittypi/runNumber.txt
eval /home/larry/wittypi/runScript.sh





#   increment runNumber
#let xRunN++;echo $xRunN > /home/larry/wittypi/runNumber.txt
