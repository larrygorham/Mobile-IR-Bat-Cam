#!/bin/bash
# file: beforeScript.sh
#
# This script will run after Raspberry Pi boot up, and before running the schedule script.
# If you want to change the schedule script before running it, you may do so here.
#
#         120  minute record video


./home/larry/raspberry-pi-opencv/twoCore/timeWrite120
./home/larry/wittypi/loadSked.sh
