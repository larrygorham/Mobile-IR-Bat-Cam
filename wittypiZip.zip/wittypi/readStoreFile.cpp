// g++ readStoreFile.cpp -o readStoreFile 
#include <stdio.h>
#include <cstdlib>

int main() {
    int runNum;
    FILE *fp;

   // Reading from file

    fp = fopen("runCount.txt", "r");
    if (fp == NULL) {
        printf("Error opening file for reading!\n");
        return 1;
    }

    fscanf(fp, "%d", &runNum);
    fclose(fp);
    printf("Number read: %d\n", runNum);
    runNum++;

    // Writing to file
    fp = fopen("runCount.txt", "w");
    if (fp == NULL) {
        printf("Error opening file for writing!\n");
        return 1;
    }

    fprintf(fp, "%d", runNum);
    fclose(fp);

    if(runNum == 1)
        std::system(". /home/larry/wittypi/runScript.sh  "); //  execute this from bash
 

    printf("Number written: %d\n", runNum);


    return 0;
}
