#!/bin/bash
# file: afterStartup.sh
#
# This script will run after Raspberry Pi boot up and finish running the schedule script.
# If you want to run your commands after boot, you can place them here.
# 
# Remarks: please use absolute path of the command, or it can not be found (by root user).
# Remarks: you may append '&' at the end of command to avoid blocking the main daemon.sh.
#

cd /home/larry/raspberry-pi-opencv/twoCore

if [ $(</media/larry/pro128e/temp.txt) == 1 ]; then 
	sleep 60
	/home/larry/raspberry-pi-opencv/twoCore/timeWrite &
else
	 sudo echo 1 > /media/larry/pro128e/temp.txt &
fi
