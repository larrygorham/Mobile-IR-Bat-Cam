// g++ p2.cpp -o p2 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <cstdlib>

#include <iostream>
#include <time.h>


#define MAX_TIMES  100
#define MAX_LINE_LENGTH  256


//#define schedulesFile.txt  "beginEndTimes.txt"  

using namespace std;
//----------------------------------------------------------------------------------------------
void getWMCCform(char tempWMCCform[32], const time_t &now){
    struct tm *timeinfo;
	
	timeinfo = localtime(&now);

    char buffer[80];


    // Format date and time (e.g., "20250124_214100")
    strftime(buffer, sizeof(buffer), "%Y%m%d_%H%M%S", timeinfo);

    // Create timeForm with date and time
    strcpy(tempWMCCform, "WMCC_SKED_");
    strcat(tempWMCCform, buffer);
    strcat(tempWMCCform, ".txt\n");

	return ;
}

void getTimeForm(char temptimeForm[30], const time_t &now){
    struct tm *timeinfo;
	
	timeinfo = localtime(&now);

    char buffer[80];


    // Format date and time (e.g., "2025-01-24 21:41:00")
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", timeinfo);

    // Create timeForm with date and time
    //strcpy(temptimeForm, "WMCC_MYLU_");
    strcat(temptimeForm, buffer);
    //strcat(temptimeForm, ".txt");

	return ;
}

int main() {    
    struct tm *timeinfo;

    char times[MAX_TIMES][MAX_LINE_LENGTH];
    char *filenameForm[MAX_TIMES][MAX_LINE_LENGTH]; //  formatted for .wpi
    char filename[100];
    FILE *timesFile;
    FILE *fp;
    FILE *runListFile;
    FILE *skedFile;

    int nRuns;         // 2
    int lineCount;
    int videoLength;  // 60   seconds
    int gapLength;  //   120  Seconds
    

    
   // Reading from timesFile

     fp = fopen("runSettings.txt", "r");
    if (fp == NULL) {
        printf("Error opening timesFile for reading!\n");
        return 1;
    }

    fscanf(fp, "%d\n", &nRuns);
    fscanf(fp, "%d\n", &videoLength);
    fscanf(fp, "%d", &gapLength);
    fclose(fp);
    printf("Number runs %d\n", nRuns);
    printf("Video Length in seconds: %d\n", videoLength);
    printf("seconds between runs: %d\n", gapLength);
    
    timesFile = fopen("beginEndTimes.txt", "r");
    if (timesFile == NULL) {
        printf("Error opening timesFile.\n");
        return 1;
    }

    // Read each line from the timesFile and store it in the array
    while (fgets(times[lineCount], MAX_LINE_LENGTH, timesFile) != NULL && lineCount < MAX_TIMES) {
        lineCount++;
    }

    fclose(timesFile);

    // Print the times read from the timesFile
    printf("times read from the beginEndTimes.txt:\n");
    for (int i = 0; i < lineCount; i++) {
        printf("%s", times[i]);
    }
 
     // Establish each run file name for the runList.txt 
    
    runListFile = fopen("runList.txt", "w");
        if (runListFile == NULL) {
        printf("Error opening runListFile.\n");
        return 1;
    }

    time_t timeT;
    for (int i = 0; i < lineCount; i+=2) {
        //printf("times[%d]: %s\n",i, times[i]);
        int intTimes = atoi(times[i]);
        //printf("intTimes: %d\n", intTimes);
        timeT = intTimes;
        //printf("timeT: %d\n", timeT);
        memset(filename,0,strlen(filename)); 
        getWMCCform(filename,timeT);
        int result = fputs(filename,runListFile);
        //printf("%s", filename);

    }
    fclose(runListFile);

    printf("File names read from runList.txt:\n");      
    runListFile = fopen("runList.txt", "r");
    if (runListFile == NULL) {
        printf("Error opening runListFile.\n");
        return 1;
    }
        
    while (fgets(filename, sizeof(filename), runListFile) != NULL) {
        printf("%s", filename);
    }

    fclose(runListFile);
 // --------------------------------------------------------------------   
    printf("build the schedule files\n");
    int beginTime,endTime;
    char beginTimeForm[80];
    char endTimeForm[80] ;   
    


    // Read each line from the timesFile and store it in the array
    while (fgets(times[lineCount], MAX_LINE_LENGTH, timesFile) != NULL && lineCount < MAX_TIMES) {
        lineCount++;
    }  
 

        // Print file names read from runListFile
    printf("times read from the beginEndTimes.txt:\n");
    for (int i = 0; i < lineCount; i++) {
        printf("%s", filenameForm[i]);
    }
    
    char *temp;
    for (int i = 0; i < nRuns; i+=1){

        beginTime = atoi(times[i*2]);
        memset(beginTimeForm,0,strlen(beginTimeForm)); 
        getTimeForm(beginTimeForm,beginTime);
        endTime   = atoi(times[i*2+1]);
        memset(endTimeForm,0,strlen(endTimeForm)); 
        getTimeForm(endTimeForm,endTime);
        printf("BEGIN    %s\n", beginTimeForm);
        printf("END      %s\n", endTimeForm);
        
        //temp = filenameForm[i];
        //temp =   strcat(filenameForm[i], NULL);
        //skedFile = fopen(temp, "w");
        skedFile = fopen(&filenameForm[i], "w");
    if (skedFile == NULL) {
        printf("Error opening skedFile.\n");
        return 1;
     }   
        fprintf(skedFile,"BEGIN    %s\n", beginTimeForm);
        fprintf(skedFile,"END      %s\n", endTimeForm);
        
        
        fclose(skedFile);
        
        
    }
        


    return 0;
}
