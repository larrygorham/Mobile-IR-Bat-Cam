// g++ p1.cpp -o p1 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <cstdlib>

#include <iostream>
#include <time.h>


#define MAX_LINES  100
#define MAX_LINE_LENGTH  256
#define filename "beginEndTimes.txt"
//#define timesFile.txt  "beginEndTimes.txt"  
//#define schedulesFile.txt  "beginEndTimes.txt"  



using namespace std;
//----------------------------------------------------------------------------------------------
void getWMCCform(char tempWMCCform[30], const time_t &now)
{
    struct tm *timeinfo;
	
	//timeinfo = localtime(&now);

    char buffer[80];


    // Format date and time (e.g., "20250124_214100")
    strftime(buffer, sizeof(buffer), "%Y%m%d_%H%M%S", timeinfo);

    // Create timeForm with date and time
    strcpy(tempWMCCform, "WMCC_SKED_");
    strcat(tempWMCCform, buffer);
    strcat(tempWMCCform, ".txt");

	return ;
}

int main() {
    //char timesFile.txt[256];
    char lines[MAX_LINES][MAX_LINE_LENGTH];
    FILE *file;
    FILE *fp;

    int nRuns;         // 2
    int lineCount;
    int videoLength;  // 60   seconds
    int gapLength;  //   120  Seconds
   // Reading from file

     fp = fopen("runSettings.txt", "r");
    if (fp == NULL) {
        printf("Error opening file for reading!\n");
        return 1;
    }

    fscanf(fp, "%d\n", &nRuns);
    fscanf(fp, "%d\n", &videoLength);
    fscanf(fp, "%d", &gapLength);
    fclose(fp);
    printf("Number runs %d\n", nRuns);
    printf("Video Length in seconds: %d\n", videoLength);
    printf("seconds between runs: %d\n", gapLength);
    
    file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    // Read each line from the file and store it in the array
    while (fgets(lines[lineCount], MAX_LINE_LENGTH, file) != NULL && lineCount < MAX_LINES) {
        lineCount++;
    }

    fclose(file);

    // Print the lines read from the file
    printf("Lines read from the file:\n");
    for (int i = 0; i < lineCount; i++) {
        printf("%s", lines[i]);
    }

    return 0;
}
