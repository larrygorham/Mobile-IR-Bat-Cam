// g++ p0.cpp -o p0 
#include <stdio.h>
#include <cstdlib>

#include <iostream>
#include <time.h>
#include <string.h>


using namespace std;
//----------------------------------------------------------------------------------------------
void getTimeForm(char temptimeForm[30], const time_t &now)
{
    struct tm *timeinfo;
	
	timeinfo = localtime(&now);

    char buffer[80];


    // Format date and time (e.g., "2025-01-24 21:41:00")
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", timeinfo);

    strcat(temptimeForm, buffer);


	return ;
}

int main() {
    
    time_t now;
    time_t nowPlus;
    time_t nowPlusPlus;
    struct tm *timeinfo;
    char timeForm[100];
    int nRuns;       //   2
    int videoLength;  //60 seconds
    int gapLength;  //120 Seconds
    int runNum;
    FILE *fp;

   // Reading from file

    fp = fopen("runSettings.txt", "r");
    if (fp == NULL) {
        printf("Error opening file for reading!\n");
        return 1;
    }

    fscanf(fp, "%d\n", &nRuns);
    fscanf(fp, "%d\n", &videoLength);
    fscanf(fp, "%d", &gapLength);
    fclose(fp);
    printf("Number runs %d\n", nRuns);
    printf("Video Length in seconds: %d\n", videoLength);
    printf("seconds between runs: %d\n", gapLength);
    
    fp = fopen("beginEndTimes.txt", "w");
    if (fp == NULL) {
        printf("Error opening file for writing!\n");
        return 1;
    }    
    // Get current time
    time(&now);
  
    for (int runN = 1; runN <= (nRuns); runN++){
       nowPlus = now + gapLength;
        getTimeForm(timeForm,nowPlus);
        printf("run%d begin time: %d   %s\n",runN,nowPlus,timeForm);
        fprintf(fp, "%d\n", nowPlus);
        fclose(fp);
        memset(timeForm,0,strlen(timeForm)); 
        
        now = nowPlus;
        fp = fopen("beginEndTimes.txt", "a");
        nowPlus = now + videoLength + gapLength;
        getTimeForm(timeForm,nowPlus);
        printf("run%d end time: %d   %s\n",runN ,nowPlus,timeForm);
        fprintf(fp, "%d\n", nowPlus);

        now = nowPlus;
        memset(timeForm,0,strlen(timeForm)); 
    
    }
    
    fclose(fp);


    return 0;
}
