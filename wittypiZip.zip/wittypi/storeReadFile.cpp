// g++ storeReadFile.cpp -o storeReadFile 
#include <stdio.h>

int main() {
    int num = 123;
    FILE *fp;

    // Writing to file
    fp = fopen("runCount.txt", "w");
    if (fp == NULL) {
        printf("Error opening file for writing!\n");
        return 1;
    }

    fprintf(fp, "%d", num);
    fclose(fp);

    // Reading from file
    int readNum;
    fp = fopen("runCount.txt", "r");
    if (fp == NULL) {
        printf("Error opening file for reading!\n");
        return 1;
    }

    fscanf(fp, "%d", &readNum);
    fclose(fp);

    printf("Number written: %d\n", num);
    printf("Number read: %d\n", readNum);

    return 0;
}
