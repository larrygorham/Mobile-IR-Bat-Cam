// g++ filenameArray.cpp -o filenameArray
#include <iostream>
#include <fstream>
#include <string>


int main() {
    std::string filenames[] = {"file1.txt", "file2.txt", "file3.txt"};

    for (int i = 0; i < 3; i++) {
        std::ofstream file(filenames[i].c_str()); // Convert to C-style string

        if (file.is_open()) {
            std::cout << "Opened file: " << filenames[i] << std::endl;
            // Process the file here
            file.close();
        } else {
            std::cerr << "Error opening file: " << filenames[i] << std::endl;
        }
    }

    return 0;
}
