#!/bin/bash
/home/larry/wittypi/afterStartup.sh

