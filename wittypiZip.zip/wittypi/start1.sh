#!/bin/bash

filename_list="/home/larry/wittypi/runList.txt"
filename_schedule="/home/larry/wittypi/schedule.wpi"

#  Starting runNumber
xRunN=1


filename=$(eval $(echo head -$xRunN $filename_list) | tail -1)
echo $filename
sudo cp $filename  $filename_schedule
#   increment runNumber
let xRunN++;echo $xRunN > /home/larry/wittypi/runNumber.txt
. /home/larry/wittypi/runScript.sh



