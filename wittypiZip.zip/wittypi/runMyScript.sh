#!/bin/bash
. /home/larry/wittypi/runScript.sh  
