// g++ filename.c -o filename 
#include <stdio.h>
#include <time.h>
#include <string.h>
//----------------------------------------------------------------------------------------------
void getFileName(char tempFileName[30], const time_t &now)
{
    struct tm *timeinfo;
	
	timeinfo = localtime(&now);

    char buffer[80];


    // Format date and time (e.g., "20241228_092600")
    strftime(buffer, sizeof(buffer), "%Y%m%d_%H%M%S", timeinfo);

    // Create filename with date and time
    strcpy(tempFileName, "WMCC_MYLU_");
    strcat(tempFileName, buffer);
    strcat(tempFileName, ".avi");

	return ;
}
int main() {
    time_t now;
    struct tm *timeinfo;
    char filename[100];

    // Get current time
    time(&now);
	//const long int intNow = now;
	//printf("time now  %d\n",intNow);
	getFileName(filename,now);
	
    // Use the filename
    FILE *fp = fopen(filename, "w");
    if (fp != NULL) {
        fprintf(fp, "Hello, world!\n");
        fclose(fp);
    } else {
        printf("Error opening file.\n");
    }

	char merge[2];
	merge[0] = &filename ;
	merge[1] = '\0';
	printf("%s\n",merge);


    return 0;
}
