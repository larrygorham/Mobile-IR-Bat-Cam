//     g++ jDate.c -o jDate 
#include <stdio.h>
#include <time.h>

int main() {
    time_t now;
    struct tm *tm_info;
    int year, month, day;
    int daysMonth[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
    time(&now);
    tm_info = localtime(&now);

    year = 2024;//tm_info->tm_year + 1900;//   
    month = 12;//tm_info->tm_mon + 1;
    day = 31;//tm_info->tm_mday;
    if(year%4 == 0)
        daysMonth[1] = 29;
    int daysOfYear = day;
    for (int i = 1;i<month;i++)
        daysOfYear += daysMonth[i-1] ;
    printf("daysOfYear:  %d\n", daysOfYear);
    printf("day  %d,   month  %d, year %d\n", day, month, year);

    return 0;
}
