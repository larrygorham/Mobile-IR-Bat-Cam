#!/bin/bash
# file: beforeScript.sh
#
# This script will run after Raspberry Pi boot up, and before running the schedule script.
# If you want to change the schedule script before running it, you may do so here.
#
#         10  minute record video


sudo ./home/larry/raspberry-pi-opencv/twoCore/timeWrite10
sudo ./home/larry/wittypi/loadSked.sh
