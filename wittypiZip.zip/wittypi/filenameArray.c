// g++ filenameArray.cpp -o filenameArray 
#include <stdio.h>
#include <stdlib.h>

int main() {
    char *filenames[] = {
        "file1.txt",
        "file2.txt",
        "file3.txt",
        NULL // Sentinel value to indicate the end of the array
    };

    FILE *file;
    int i = 0;

    while (filenames[i] != NULL) {
        file = fopen(filenames[i], "r"); // Open in read mode

        if (file == NULL) {
            perror("Error opening file");
            exit(1);
        }

        // Do something with the file (e.g., read its contents)
        // ...

        fclose(file);
        i++;
    }

    return 0;
}
