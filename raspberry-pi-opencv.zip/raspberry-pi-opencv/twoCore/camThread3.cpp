//   g++ camThread.cpp -o camThread `pkg-config --cflags --libs opencv4`

#include <opencv2/opencv.hpp>
#include <thread>
#include <mutex>

using namespace cv;
using namespace std;

class CameraThread {
public:
    CameraThread(int cameraIndex) : cameraIndex(cameraIndex), running(false) {}

    void start() {
        running = true;
        thread0 = std::thread(&CameraThread::run, this);
    }

    void stop() {
        running = false;
        thread0.join();
    }

    Mat getFrame() {
        std::lock_guard<std::mutex> lock(frameMutex);
        return frame0.clone();
    }

private:
    int cameraIndex;
    bool running;
    std::thread thread0;
    Mat frame0;
    std::mutex frameMutex;

    void run() {

        VideoCapture cap(0, CAP_V4L);  //  recommended when capturing a webcam
        // check if we succeeded
        if (!cap.isOpened()) {
            cerr << "ERROR! Unable to open camera\n";
            return;
        }

        while (running) {
            Mat frameLocal;
            cap >> frameLocal;

            if (!frameLocal.empty()) {
                std::lock_guard<std::mutex> lock(frameMutex);
                frame0 = frameLocal.clone();
            }
        }
    }
};



/*
    cap.set(CAP_PROP_FRAME_WIDTH, 640);//Setting the width of the video   720
    cap.set(CAP_PROP_FRAME_HEIGHT, 480);//Setting the height of the video    480
    VideoWriter writer;
    int codec = VideoWriter::fourcc('M', 'J', 'P', 'G');  // select desired codec (must be available at runtime)
    double fps = 30.0;                          // framerate of the created video stream
    string filename = "/home/larry/raspberry-pi-opencv/twoCore/live.avi";             // name of the output video file
    writer.open(filename, codec, fps, {640,480}, 1);  //  0  means not color

    writer.write(frame);
*/

int main() {
    CameraThread camera(0);
    camera.start();

    while (true) {
        Mat frame0 = camera.getFrame();

        if (!frame0.empty()) {
            imshow("Camera", frame0);
        }

        if (waitKey(1) == 27) {
            break;
        }
    }

    camera.stop();
    return 0;
}
