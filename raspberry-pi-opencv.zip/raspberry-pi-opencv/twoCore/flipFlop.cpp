// C program to demonstrate the array 
//   g++ flipFlop.cpp -o out

#include <stdio.h>
#include <time.h>
#include <thread>
#include <atomic>

#define ARRAYSIZE 16
#define UPDATES 4
#define invert(r)  (r+1)%2


int flip = 0;
int flop = 0;


// Defining global array within and structure
typedef struct{
    int frame0[ARRAYSIZE] = {0};
    int frame1[ARRAYSIZE] = {0};
} Input_t ;

void delay_usec(int number_of_usecs){

    // Storing start time
    clock_t start_time = clock();

    // looping till required time is not achieved
    while (clock() < start_time + number_of_usecs);
}



void capture (Input_t* input){  // capture definition

  for (int iUpS = 0 ; iUpS <  UPDATES; iUpS++){

        while (flip != flop){
            delay_usec(1);
        }

        delay_usec(1e6); // big delay
        
        if(flip == 0){
            for (int inc = 0; inc < ARRAYSIZE; inc++) {
                input->frame0[inc] =  inc;
            }
        }else{
            for (int inc = 0; inc < ARRAYSIZE; inc++) {
                input->frame1[inc] =  inc + ARRAYSIZE;
            }
        }
        printf(" capture flip = %d  flop = %d\n",flip,flop);
        flip = invert(flip);
        

    }

}

void record (Input_t* input){  // record definition

     for (int iUpS = 0 ; iUpS <  UPDATES; iUpS++){

        while (flip == flop){

            delay_usec(1);
        }

        if(flip == 1){
            printf("\n  frame1 ");
            for (int inc = 0; inc < ARRAYSIZE; inc++) {
                printf("%d ", input->frame0[inc]);
            }
        }else{
            printf("\n  frame0 ");
            for (int inc = 0; inc < ARRAYSIZE; inc++) {
                printf("%d ", input->frame1[inc]);
            }
        }
        printf(" record flip = %d  flop = %d\n",flip,flop);
        flop = invert(flop);
    }
 
}

int main(){

    // Declares structure variable
    Input_t input;
    
      std::thread t0, t1;
    
      //Launch two threads
  t1 = std::thread(record, &input);// waits until frame is ready
  t0 = std::thread(capture, &input);// goes at the frame rate

    
  t0.join();
  t1.join();
  
      printf("\n   ");
      
    return 0;
}

