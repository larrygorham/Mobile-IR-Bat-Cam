//   g++ countRate.cpp -o out `pkg-config --cflags --libs opencv4`

#include <opencv2/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <stdio.h>
#include <time.h>
#include <cstdlib>


using namespace cv;
using namespace std;


int keyboard;


int main(int, char**)
{
	Mat imgOriginal;
	VideoWriter writer;
			
    VideoCapture cap(0, CAP_V4L); //capture the video from web cam

    if (!cap.isOpened())  // if not success, exit program
    {
        cout << "Cannot open the web cam" << endl;
        return -1;
    }
	
	
	
    cap.set(CAP_PROP_FOURCC, VideoWriter::fourcc('M', 'J', 'P', 'G'));
    cap.set(CAP_PROP_FRAME_WIDTH,640);  //640     1280
    cap.set(CAP_PROP_FRAME_HEIGHT, 480);  //480     720
    cap.set(CAP_PROP_FPS, 30);

    //while ((char)keyboard != 'q' && (char)keyboard != 27)
    //long int start = std::stol(std::system("echo date +%s"));
    time_t epochTime = time(nullptr); 

    // Cast to long int if necessary
    //int epochSeconds = epochTime; 

    //std::cout << "Epoch seconds: " << epochSeconds << std::endl;
    for (int fn = 0;fn < 30*60;fn++) 
    {

        //clock_t a = clock();
        bool bSuccess = cap.read(imgOriginal); 

        //if (!bSuccess)
        //{
        //    cout << "Cannot read a frame from video stream" << endl;
        //    break;
        //}
        //printf("Captue Time : %f\n", double(clock() - a) / double(CLOCKS_PER_SEC));

        imshow("Original", imgOriginal);
        if (waitKey(1) == 27) 
        {
            cout << "esc key is pressed by user" << endl;
            break;
        }

    }
    //epochTime = time(nullptr); 

    // Cast to long int if necessary
    //long int epochSeconds = static_cast<long int>(epochTime); 
    
    cout << "elasped seconds:   " << time(nullptr) - epochTime << endl;

    return 0;

}
