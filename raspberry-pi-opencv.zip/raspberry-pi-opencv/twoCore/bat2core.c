// sample2uSD.ino
// Demonstrates two buffers and two processors alternately sampling and storing to uSD
// 12 bit sampling A0 at 210,000 samples/sec, storing to uSD much faster.  
// Larry Gorham
// This code is public domain
//
#include <SPI.h>


#include "arduinoFFT.h"

#define pi 3.14159
#define BUFFSIZE 2048 //  512 Size of single buffer.
#define UPDATES 209*15     //104.5/sec 209 is 2 sec   209*5
#define invert(r)  (r+1)%2
#define fd 30000     //  Detection frequency 40000
#define timerSec  5 // secs for each detection recording
#define LED 25



uint16_t buff0[BUFFSIZE] = {0}; // 
uint16_t buff1[BUFFSIZE] = {0}; // 
float buffF[BUFFSIZE]; 
float buffR[BUFFSIZE] = {0.}; 
float fs = 214000.;

const float alpha = 1-.18;   //  These come from Mathematica 
    


static uint16_t flip = 0;
static uint16_t flop = 0;
uint16_t flagW = 0;
uint32_t hdrDiv = 65536;
uint32_t ctrB = 1; //  Block counter
uint16_t fdBin  = round(fd*BUFFSIZE/fs)+1; // center bin for the detection band
uint32_t fl = 0;
uint16_t ctrTime = 0;// record time block counter 
static float pwrD = 0.;
const uint16 PwrThres = 65535;  //  
uint16_t timerSecN;

float bufferTime = (float) BUFFSIZE/fs; // buffer length in sec
uint16_t printBuff[BUFFSIZE] = {0};
uint16_t writeBuff[BUFFSIZE] = {0};
uint16_t readBuff[BUFFSIZE] = {0};
uint16_t head[BUFFSIZE] = {0}; // zero the record header block

//----------  SD  Configs  --------------------------
#include <SPI.h>
#include "SdFat.h"
#include "sdios.h"
#include "FreeStack.h"
#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/gpio.h"

//  SD_FAT_TYPE = 0 for SdFat/File as defined in SdFatConfig.h,
//  1 for FAT16/FAT32, 2 for exFAT, 3 for FAT16/FAT32 and exFAT.
#define SD_FAT_TYPE 2

const uint8_t SD_CS_PIN = SS;

#define SPI_CLOCK SD_SCK_MHZ(25) // 50
#define SD_CONFIG SdSpiConfig(SD_CS_PIN, DEDICATED_SPI, SPI_CLOCK)
#define error(dum)   Serial.printf("%s\n", dum);
#define GPIO16pad ((uint32_t*)0x4001c044)   //  pin 21
#define GPIO19pad ((uint32_t*)0x4001c050)   //  pin 25
#define SMPS_MODE  True

// Set PRE_ALLOCATE true to pre-allocate file clusters.
const bool PRE_ALLOCATE = true;

const uint64_t MAX_FILE_SIZE = (BUFFSIZE*UPDATES+1024)*2 ;  //(pow(2,32) - 1) 

//========================  End SD Configs  =================================================

SdExFat sd;
ExFile file;

//**********************************************************************

void setup() {

  pinMode(LED, OUTPUT);
  Serial.begin(115200);
  // Wait for USB Serial
  while (!Serial) {
    yield();
  }
  //for (uint16_t j=0;j<BUFFSIZE;j++){
  //  buffF[j] = 0.;
  //}
  head[0] = 61440; //  F000
  timerSecN = round((float) timerSec/bufferTime); //  buffers for  each recording
  delay(1); 
  if (!ENABLE_DEDICATED_SPI) {
    Serial.printf("\nSet ENABLE_DEDICATED_SPI nonzero\n");
  }


  if (!sd.begin(SD_CONFIG)) {
    sd.initErrorHalt(&Serial);
  }



  // open or create file - truncate existing file.
  if (!file.open("bench.dat", O_RDWR | O_CREAT | O_TRUNC)) {
    error("open failed");
  }


  if (PRE_ALLOCATE) {
    if (!file.preAllocate((uint64_t)MAX_FILE_SIZE)) {
      error("preAllocate failed");
    }
  }

  *GPIO16pad = 0x46;  //   sets drive strength to 2mA
  *GPIO19pad = 0x46;

  digitalWrite(LED, HIGH); 


  uint32_t temp = 0;
  uint16_t ctrB = 1; //  Block counter
  for (uint32_t iUpW = 0 ; iUpW <  UPDATES ; iUpW++){


    while (flip == flop){
      asm volatile (" nop\n"); //  smallest delay
    }

      ctrB++;
      if (flip == 1){
        if (flagW == 0){ 
          pwrD = 0.;
          buffF[0] = 0.;
          for (uint16_t j=1;j<BUFFSIZE;j++){
            buffR[j] = (float) buff0[j];
            // This will be the filtered output

            buffF[j] = buffR[j] - buffR[j-1] + buffF[j-1]*alpha; 


            pwrD += (buffF[j]); // abs

            //if (j<10)
            //  Serial.printf("j = %d, buffR[j] = %f, flop = %d\n\r",j,buffR[j],flop);
          }



          if (pwrD > PwrThres){ 
            flagW = 1;    //   bat detection
            head[1] = floor(iUpW/hdrDiv); // upper half of detection block counter
            head[2] = iUpW - head[1]*hdrDiv; //lower half of detection block counter
            //head[3] = floor(pwrD);

            if (file.write(head, BUFFSIZE*2) != BUFFSIZE*2) {  //  write header block
              error("write buff failed");
            }
          }  
        }else{
          if (file.write(buff0, BUFFSIZE*2) != BUFFSIZE*2) {  //  writes in bytes
            error("write buff0 failed");
          }
          ctrTime++;
          if (ctrTime > timerSecN){
            flagW = 0;
            ctrTime = 0;
          }
        } 
      }else{
        if (flagW == 0){
          pwrD = 0.;
          buffF[0] = buff1[0];
          for (uint16_t j=1;j<BUFFSIZE;j++){
            buffR[j] = (float) buff1[j];
            // This will be the filtered output

             buffF[j] = buffR[j] - buffR[j-1] + buffF[j-1]*alpha; 

            pwrD += (buffF[j]);  //abs

            //if (j<10)
            //  Serial.printf("j = %d, buffR[j] = %f, flop = %d\n\r",j,buffR[j],flop);
          }

          if (pwrD > PwrThres){ 
            flagW = 1;    //   bat detection
            head[1] = floor(iUpW/hdrDiv); // upper half of detection block counter
            head[2] = iUpW - head[1]*hdrDiv; //lower half of detection block counter
            //head[3] = floor(pwrD);

            if (file.write(head, BUFFSIZE*2) != BUFFSIZE*2) {  //  write header block
              error("write buff failed");
            }
          }  
        }else{
          if (file.write(buff1, BUFFSIZE*2) != BUFFSIZE*2) {  //  writes in bytes
            error("write buff1 failed");
          }
          ctrTime++;
          if (ctrTime > timerSecN){
            flagW = 0;
            ctrTime = 0;
          }
        }
      }

      flop = invert(flop);
      //Serial.printf("INSIDE WRITE flip = %d, flop = %d, flagW = %d,ctrB = %d,pwrD = %e\n\r",flip,flop,flagW,ctrB,pwrD);
      //Serial.printf("IW iUpW = %d, ctrTime = %d, timerSecN = %d, fdBin = %d\n\r",iUpW,ctrTime,timerSecN,fdBin);
    

  
  }

  digitalWrite(LED, LOW); 

   //Serial.printf("OUTSIDE WRITE flip = %d, flop = %d, flagW = %d,ctrB = %d,pwrD = %3\n\r",flip,flop,flagW,ctrB,pwrD);
   //Serial.printf("OW ctrTime = %d, timerSecN = %d, fdBin = %d\n\r",ctrTime,timerSecN,fdBin);

    //  *********************    read what was written to  uSD **********************
  //file.rewind();


/*
  for (uint32_t iUp = 0 ; iUp <  UPDATES ; iUp++){  
    int32_t nr = file.read(readBuff, BUFFSIZE*2);   // reads in bytes
    if (nr != BUFFSIZE*2) {
     error("read failed");
    }

    for (uint32_t iOut = 0; iOut < BUFFSIZE ; iOut++){
      printBuff[iOut] = readBuff[iOut];
    }

    //Serial.printf("Read it back\n");
    for (uint32_t i = 0; i < 40 ; i++){
      //Serial.printf("%8d  %4d\n\r",i,printBuff[i]);
    }

        for (uint32_t i = BUFFSIZE-40; i < BUFFSIZE ; i++){
      //Serial.printf("%8d  %4d\n\r",i,printBuff[i]);
    }

  }

*/

  file.close();
  sd.end();

}




void loop() {}

// ***************************Running on Core1*****************************************************
void setup1() {

//  Serial.begin(115200);


  delay(3000);

  flip = 0;
  flop = 0;

  //****************   Sampling   ***********************

  analogReadResolution(12);

  for (uint32_t iUpS = 0 ; iUpS <  UPDATES; iUpS++){

    while (flip != flop){
      asm volatile (" nop\n"); //  smallest delay
    }

    if (flip == 0){
      for (uint32_t iTo = 0; iTo < BUFFSIZE; iTo++) {
        buff0[iTo] = analogRead(A0);  
      }
    }else{
      for (uint32_t iTo = 0; iTo < BUFFSIZE; iTo++) {
        buff1[iTo] = analogRead(A0);
      }     
    }

    delay(2);

    flip = invert(flip);


    //Serial.printf("INSIDE ADC flip = %d, flop = %d, flagW = %d,ctrB = %d,pwrD = %e\n\r",flip,flop,flagW,ctrB,pwrD);
    //Serial.printf("IS iUpS = %d, ctrTime = %d, timerSecN = %d, fdBin = %d\n\r",iUpS,ctrTime,timerSecN,fdBin);

  }

  //Serial.printf("OUTSIDE ADC flip = %d, flop = %d, flagW = %d,ctrB = %d,pwrD = %e\n\r",flip,flop,flagW,ctrB,pwrD);
  //Serial.printf("OS ctrTime = %d, timerSecN = %d, fdBin = %d\n\r",ctrTime,timerSecN,fdBin);
}

void loop1() {}
