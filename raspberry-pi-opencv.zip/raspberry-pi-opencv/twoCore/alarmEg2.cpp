// g++ alarmEg.cpp -o alarmEg

#include <stdio.h>
#include <unistd.h>
#include <signal.h>

int counter;

static void alarmHandler(int signo);

int main(void){

    alarm(15);

    signal(SIGALRM, alarmHandler);

    for(counter = 1; counter < 30; counter++){
        //printf("%d\n", i);
        sleep(1);    
    }

    return 0;

}

static void alarmHandler(int signo){
    printf("Alarm signal sent!,  counter : %d\n",counter);

}
