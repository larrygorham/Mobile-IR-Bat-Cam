//   g++ passMat.cpp -o out `pkg-config --cflags --libs opencv4`
//   g++ passMat.cpp -o passMat `pkg-config --cflags --libs opencv4`
#include <atomic>
#include <thread>
#include "opencv2/opencv.hpp"
#include <iostream>
#include <string>

using namespace std;
using namespace cv;

//Mat frame;

atomic_bool stop = ATOMIC_VAR_INIT(false);

void captureFrames(VideoCapture& cap, Mat& frame) {

        while(!stop) {
            //  mat frame;
            cap >> frame;
            if (frame.empty())
                break;
            //video.write(frame);
        }
        cap.release();

        return;
}

int main() {
    VideoCapture cap(0, CAP_V4L); 
    VideoWriter video;
    int codec = VideoWriter::fourcc('M', 'J', 'P', 'G');  // select desired codec (must be available at runtime)
    double fps = 30.0;                          // framerate of the created video stream
    string filename = "./live.avi";             // name of the output video file
    video.open(filename, codec, fps, {640,480}, 0);  //  0  means not color
    if (!cap.isOpened()) {
        std::cerr << "Error opening video stream" << std::endl;
        return -1;
    }

    Mat frame;
    cv::Mat gray;
    
    cout << "Capturing the video. Press Esc + enter to stop " << endl;
    
    std::thread captureThread(captureFrames, std::ref(cap), std::ref(frame));

    while (true) {
        if (!frame.empty()) {
            cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
            imshow("Live", gray);
            video.write(gray);
        }
        
    
        char c = (char)waitKey(1);
        if (c == 27) {
            stop = true;
            break;
        }
    }

    captureThread.join();
    cap.release();
    video.release();
    destroyAllWindows();
    return 0;
}

