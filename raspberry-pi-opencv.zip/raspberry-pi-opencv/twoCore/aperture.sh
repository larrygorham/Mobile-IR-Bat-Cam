#!/bin/bash

num=$1
v4l2-ctl --set-ctrl exposure_time_absolute=$num
