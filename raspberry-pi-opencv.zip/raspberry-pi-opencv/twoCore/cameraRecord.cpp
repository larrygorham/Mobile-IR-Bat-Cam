// C program to demonstrate the array 
//  g++ cameraRecord.cpp -o out `pkg-config --cflags --libs opencv4`
//  g++ cameraRecord.cpp -o cameraRecord `pkg-config --cflags --libs opencv4`

#include <atomic>
#include <stdio.h>
#include <time.h>
#include <thread>
#include "opencv2/opencv.hpp"
#include <iostream>
#include <string>

using namespace std;
using namespace cv;

int cFlag = 1;
int rFlag = 0;

#define UPDATES 30*120
#define invert(r)  (r+1)%2



void delay_usec(int number_of_usecs){

    // Storing start time
    clock_t start_time = clock();

    // looping till required time is not achieved
    while (clock() < start_time + number_of_usecs);
}

void capture (VideoCapture& cap,  Mat& frame0, Mat& frame1){  // capture definition
        cap >> frame1;
        cFlag = invert(cFlag);
  for (int iUpS = 0 ; iUpS <  UPDATES; iUpS++){

        //while (cFlag != rFlag){
            //delay_usec(1);
        //}

        // delay_usec(1); 
        // printf(" befor capture cFlag = %d  rFlag = %d  loop = %d\n",cFlag,rFlag,iUpS);
        if(cFlag == 0){
            cap >> frame0;
        }else{
            cap >> frame1;
        }

        cFlag = invert(cFlag);
        // printf(" after capture cFlag = %d  rFlag = %d  loop = %d\n",cFlag,rFlag,iUpS);
    }
    cap.release();
    return;
}


void record (VideoCapture& cap, Mat& frame0, Mat& frame1, Mat& gray){  // record definition

    VideoWriter video;
    int codec = VideoWriter::fourcc('M', 'J', 'P', 'G');  // select desired codec (must be available at runtime)
    double fps = 30.0;                          // framerate of the created video stream
    string filename = "./live.avi";             // name of the output video file
    video.open(filename, codec, fps, {640,480}, 1);  //  0  means not color
    if (!cap.isOpened()) {
        std::cerr << "Error opening video stream" << std::endl;
    }
     for (int iUpS = 0 ; iUpS <  UPDATES; iUpS++){

        while (cFlag != rFlag){
            //delay_usec(1);
        }
        // printf(" before record cFlag = %d  rFlag = %d  loop = %d\n",cFlag,rFlag,iUpS);
        rFlag = invert(rFlag);
        if(rFlag == 0){

            if (!frame0.empty()) {
                //cvtColor(frame0, gray, cv::COLOR_BGR2GRAY);
                //imshow("Live", gray);
                video.write(frame0);
            }
        }else{

            if (!frame1.empty()) {
                //cvtColor(frame1, gray, cv::COLOR_BGR2GRAY);
                //imshow("Live", gray);
                video.write(frame1);
            }
        }

        // printf(" after record cFlag = %d  rFlag = %d  loop = %d\n",cFlag,rFlag,iUpS);
    }
    return;
}


int main(){


    VideoCapture cap(0, CAP_V4L); //   CAP_V4L 

    cv::Mat frame0;
    cv::Mat frame1;
    cv::Mat gray;
    
    
    cout << "Capturing the video. Press Esc + enter to stop " << endl;

    
      //Launch two threads

    std::thread t1(record, std::ref(cap), std::ref(frame0), std::ref(frame1), std::ref(gray));
        // waits until frame is ready
    std::thread t0(capture, std::ref(cap), std::ref(frame0), std::ref(frame1));
        // might wait until t1 is done, hopefully 30 fps
    
    t0.join();
    t1.join();
  
    cap.release();

    destroyAllWindows();
    // printf("\n   ");
    return 0;
}

