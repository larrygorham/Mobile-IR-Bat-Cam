//   g++ countRate.cpp -o out `pkg-config --cflags --libs opencv4`

#include <opencv2/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <stdio.h>
#include <time.h>
#include <cstdlib>


using namespace cv;
using namespace std;


int keyboard;


int main(int, char**)
{
	Mat imgOriginal;
    Mat gray;
	//VideoWriter writer;
			
    VideoCapture cap(0, CAP_V4L); //capture the video from web cam

    if (!cap.isOpened())  // if not success, exit program
    {
        cout << "Cannot open the web cam" << endl;
        return -1;
    }
	
	
	
    //cap.set(CAP_PROP_FOURCC, VideoWriter::fourcc('M', 'J', 'P', 'G'));
    cap.set(CAP_PROP_FRAME_WIDTH,640);  //640     1280
    cap.set(CAP_PROP_FRAME_HEIGHT, 480);  //480     720
    cap.set(CAP_PROP_FPS, 30);




    time_t epochTime = time(nullptr); 

    for (int fn = 0;fn < 30*60;fn++) 
    {

        bool bSuccess = cap.read(imgOriginal); 

        //cvtColor(imgOriginal, gray, COLOR_BGR2GRAY);
        // encode the frame into the videofile stream

        //writer.write(imgOriginal);
        // show live and wait for a key with timeout long enough to show images

        imshow("Original", imgOriginal);
        if (waitKey(1) == 27) 
        {
            cout << "esc key is pressed by user" << endl;
            break;
        }

    }

    
    cout << "elasped seconds:   " << time(nullptr) - epochTime << endl;
    //writer.release();
    return 0;

}
