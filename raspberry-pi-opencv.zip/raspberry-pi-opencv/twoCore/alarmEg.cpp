// g++ alarmEg.cpp -o alarmEg

#include <stdio.h>
#include <unistd.h>
#include <signal.h>

#define duration 15    //    seconds

int flag = 1;

static void alarmHandler(int signo){
    flag = 0;
}

int main(void){

    alarm(duration);

    signal(SIGALRM, alarmHandler);
    int i;
    while(flag){
        printf("%d\n", i);
        sleep(1); 
        i++;
    }
    printf("Alarm signal received!,  flag:  %d\n",flag);
    return 0;

}


