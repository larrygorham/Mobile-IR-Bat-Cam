// C program to demonstrate the array wit

#include <stdio.h>
#include <time.h>
#include <thread>

#define ARRAYSIZE 16
#define UPDATES 3
#define invert(r)  (r+1)%2

// Defining array within and structure
typedef struct{
    int v0[ARRAYSIZE] = {0};
    int v1[ARRAYSIZE] = {0};
    int flip = 0;
    int flop = 0;
} Input_t ;

void delay_usec(int number_of_usecs){

    // Storing start time
    clock_t start_time = clock();

    // looping till required time is not achieved
    while (clock() < start_time + number_of_usecs);
}


void capture (Input_t* input){  // capture definition

  for (int iUpS = 0 ; iUpS <  UPDATES; iUpS++){

        while ( input->flip !=  input->flop){
            delay_usec(1);
        }

        delay_usec(5e6);
        if(input->flip == 0){
            for (int inc = 0; inc < ARRAYSIZE; inc++) {
                input->v0[inc] =  inc;
            }
        }else{
            for (int inc = 0; inc < ARRAYSIZE; inc++) {
                input->v1[inc] =  inc + ARRAYSIZE;
            }
        }
        printf(" capture flip = %d  flop = %d\n",input->flip,input->flop);
        input->flip = invert(input->flip);

    }

}

void record (Input_t* input){  // record definition

     for (int iUpS = 0 ; iUpS <  UPDATES; iUpS++){

        while ( input->flip ==  input->flop){
            delay_usec(1);
        }

        if(input->flip == 0){
            printf("\n  v1 ");
            for (int inc = 0; inc < ARRAYSIZE; inc++) {
                printf("%d ", input->v1[inc]);
            }
        }else{
            printf("\n  v0 ");
            for (int inc = 0; inc < ARRAYSIZE; inc++) {
                printf("%d ", input->v0[inc]);
            }
        }
        printf(" record flip = %d  flop = %d\n",input->flip,input->flop);
        input->flop = invert(input->flop);
    }
 
}

int main(){

    // Declares structure variable
    Input_t input;
    
      std::thread t0, t1;
    
      //Launch two threads
  t1 = std::thread(record, &input);// waits until frame is ready
  t0 = std::thread(capture, &input);// goes at the frame rate

    
  t0.join();
  t1.join();
  
      printf("\n   ");
      
    return 0;
}

