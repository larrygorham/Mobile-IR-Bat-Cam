//   g++ cameraThread.cpp -o cameraThread `pkg-config --cflags --libs opencv4`
//   g++ cameraThread.cpp -o out `pkg-config --cflags --libs opencv4`
#include <atomic>
#include <thread>
#include "opencv2/opencv.hpp"
#include <iostream>
#include <string>

using namespace std;
using namespace cv;

Mat frame;

atomic_bool stop = ATOMIC_VAR_INIT(false);

int saveNoDisplay() {
    VideoCapture cap(0, CAP_V4L); 
    if (!cap.isOpened()) {
        cout << "Error opening video stream." << endl;
        return -1;
    }
    else {
    VideoWriter video;
    int codec = VideoWriter::fourcc('M', 'J', 'P', 'G');  // select desired codec (must be available at runtime)
    double fps = 30.0;                          // framerate of the created video stream
    string filename = "./live.avi";             // name of the output video file
    video.open(filename, codec, fps, {640,480}, 1);  //  0  means not color
        while(!stop) {
            //  mat frame;
            cap >> frame;
            if (frame.empty())
                break;
            video.write(frame);
        }
        cap.release();
        video.release();
        return 0;
    }
}

int main() {
 
    cout << "Capturing the video. Press Esc + enter to stop and save."
         << endl;
    thread workerThread(saveNoDisplay);
    char c;
    while (true) {
        c = getchar();
        if (c == 27) {
            stop = true;
            break;
        }
    }

    workerThread.join();

    destroyAllWindows();
    return 0;
}
