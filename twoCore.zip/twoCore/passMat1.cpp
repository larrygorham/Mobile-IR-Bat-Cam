//   g++ passMat.cpp -o passMat `pkg-config --cflags --libs opencv4`
#include <iostream>
#include <thread>
#include <opencv2/opencv.hpp>

using namespace cv;

void captureFrames(VideoCapture& cap, Mat& frame) {
    while (true) {
        cap >> frame;
        if (frame.empty()) {
            break;
        }
    }
}

int main() {
    VideoCapture cap(0, CAP_V4L); 
    if (!cap.isOpened()) {
        std::cerr << "Error opening video stream" << std::endl;
        return -1;
    }

    Mat frame;
    std::thread captureThread(captureFrames, std::ref(cap), std::ref(frame));

    while (true) {
        if (!frame.empty()) {
            imshow("Live", frame);
        }
        if (waitKey(5) == 27) { // Exit if 'Esc' is pressed
            break;
        }
    }

    captureThread.join();
    cap.release();
    destroyAllWindows();
    return 0;
}

