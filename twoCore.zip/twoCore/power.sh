[ -z $BASH ] && { exec bash "$0" "$@" || exit; }
#!/bin/bash
# file: temp.sh
#
# Run this application to interactly configure your Witty Pi
#
# include utilities scripts in same directory
my_dir="`dirname \"$0\"`"
my_dir="`( cd \"$my_dir\" && pwd )`"
if [ -z "$my_dir" ] ; then
  exit 1
fi
. $my_dir/utilities.sh

if [ $(is_mc_connected) -ne 1 ]; then
  echo ''
  log 'Seems Witty Pi board is not connected? Quitting...'
  echo ''
  exit
fi

if one_wire_confliction ; then
	echo ''
	log 'Confliction detected:'
	log "1-Wire interface is enabled on GPIO-$HALT_PIN, which is also used by Witty Pi."
	log 'You may solve this confliction by moving 1-Wire interface to another GPIO pin.'
	echo ''
	exit
fi

# do not run further if wiringPi is not installed
if ! hash gpio 2>/dev/null; then
  echo ''
  log 'Seems wiringPi is not installed, please run again the latest installation script to fix this.'
  echo ''
  exit
fi

if [ $(is_mc_connected) -eq 1 ]; then
  firmwareID=$(i2c_read 0x01 $I2C_MC_ADDRESS $I2C_ID)
  firmwareRev=$(i2c_read 0x01 $I2C_MC_ADDRESS $I2C_FW_REVISION)
fi



if [ $(is_mc_connected) -eq 1 ]; then
  vin=$(get_input_voltage)
  vout=$(get_output_voltage)
  iout=$(get_output_current)
  tout=$(get_temperature)
  voltages=""
#  if [ $(get_power_mode) -ne 0 ]; then
    voltages+="Vin=$(printf %.02f $vin)V, "
# fi
  voltages+="Vout=$(printf %.02f $vout)V, computer=$(printf %.02f $iout)A  $(printf %s $tout)"

  echo "$voltages"
fi

