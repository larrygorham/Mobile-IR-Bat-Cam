//   g++ fastWrite.cpp -o out `pkg-config --cflags --libs opencv4`

#include <opencv2/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <stdio.h>
#include <time.h>

//#include <stack>
//#include <math.h>
//#include "opencv2/imgproc/imgproc.hpp"
//#include <opencv2/video.hpp>
//#include "opencv2/imgcodecs.hpp"



using namespace cv;
using namespace std;


int keyboard;


int main(int, char**)
{
	Mat imgOriginal;
	VideoWriter writer;
			
    VideoCapture cap(0, CAP_V4L); //capture the video from web cam

    if (!cap.isOpened())  // if not success, exit program
    {
        cout << "Cannot open the web cam" << endl;
        return -1;
    }
	
	
	
    cap.set(CAP_PROP_FOURCC, VideoWriter::fourcc('M', 'J', 'P', 'G'));
    cap.set(CAP_PROP_FRAME_WIDTH,640);  //640     1280
    cap.set(CAP_PROP_FRAME_HEIGHT, 480);  //480     720
	
	int codec = VideoWriter::fourcc('M', 'J', 'P', 'G');  // select desired codec (must be available at runtime)
	double fps = 30.0;                          // framerate of the created video stream
	string filename = "/media/larry/pro128e/output_0001.avi";             // name of the output video file 
	writer.open(filename, codec, fps, {640,480}, 0);  //  0  means not color

    if (!writer.isOpened()) {    	    // check if we succeeded
        cerr << "Could not open the output video file for write\n";
        return -1;
    }

    cv::Mat gray;

    for (int fn = 0;fn < 30*120;fn++)    //   30*60   gives one minute

    {

        //clock_t a = clock();
        bool bSuccess = cap.read(imgOriginal); 

        if (!bSuccess)
        {
            cout << "Cannot read a frame from video stream" << endl;
            break;
        }
        //printf("Captue Time : %f\n", double(clock() - a) / double(CLOCKS_PER_SEC));

        cvtColor(imgOriginal, gray, cv::COLOR_BGR2GRAY);
        // encode the frame into the videofile stream

        writer.write(gray);

        //if (waitKey(1) == 27) 
        //{
        //    cout << "esc key is pressed by user" << endl;
        //    break;
        //}
    }

    return 0;

}