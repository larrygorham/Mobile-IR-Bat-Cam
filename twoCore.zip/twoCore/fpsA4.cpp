//     +++
//     g++ fpsA.cpp -o fpsA `pkg-config --cflags --libs opencv4`  -lwiringPi
//   This does everything but not at 30 fps for all cmeras
#include <opencv2/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <cstdlib>
#include <unistd.h>
#include <signal.h>
#include <wiringPi.h>
#include <wiringPiSPI.h>

#define duration 60    // Record iength in  seconds    325

using namespace cv;
using namespace std;

int flag = 1;

static void alarmHandler(int signo){
    flag = 0;
}

void getFileName(char tempFileName[30], const time_t &now)
{ 
    struct tm *timeinfo;
	
	timeinfo = localtime(&now);

    char buffer[80];


    // Format date and time (e.g., "20241228_092600")
    strftime(buffer, sizeof(buffer), "%Y%m%d_%H%M%S", timeinfo);


    // Create filename with date and time
    strcpy(tempFileName, "/mnt/usb1/WMCC_MYLU_");
    //strcpy(tempFileName, "/media/larry/pro128e/WMCC_MYLU_");
    strcat(tempFileName, buffer);
    strcat(tempFileName, ".avi");

	return ;
}

void getTextFileName(char tempFileName[30], const time_t &now)
{
    struct tm *timeinfo;
	
	timeinfo = localtime(&now);

    char buffer[80];


    // Format date and time (e.g., "20241228_092600")
    strftime(buffer, sizeof(buffer), "%Y%m%d_%H%M%S", timeinfo);


    // Create filename with date and time
    strcpy(tempFileName, "/mnt/usb1/WMCC_MYLU_");
    //strcpy(tempFileName, "/media/larry/pro128e/WMCC_MYLU_");
    strcat(tempFileName, buffer);
    strcat(tempFileName, ".txt");

	return ;
}

int main(int, char**)
{
    
    time_t now;
    struct tm *timeinfo;
	char filename[100];
    int frameCounter = 0;
    
    printf("wiringPiSPISetup RC=%d\n",wiringPiSPISetup(0,500000));

    alarm(duration + 1);
    signal(SIGALRM, alarmHandler);

    Mat src;
    
    int ledPin = 4; // GPIO pin to IR SSR
    wiringPiSetup(); // Initialize wiringPi
    pinMode(ledPin, OUTPUT); // Set LED pin as output
    digitalWrite(ledPin, HIGH); // IR on
    
        //  Trying to fix the framerate
    std::system("exec v4l2-ctl -c auto_exposure=1 "); //  3  is automatic
    std::system("exec v4l2-ctl -c exposure_time_absolute=315 ");
    std::system("exec v4l2-ctl -c exposure_dynamic_framerate=0 ");   //  




    VideoCapture cap(0, CAP_V4L);  //  recommended when capturing a webcam
    // check if we succeeded
    if (!cap.isOpened()) {
        cerr << "ERROR! Unable to open camera\n";
        return -1;
    }
    cap.set(CAP_PROP_FRAME_WIDTH, 640);//Setting the width of the video   720
    cap.set(CAP_PROP_FRAME_HEIGHT, 480);//Setting the height of the video    480

    // get one frame from camera to know frame size and type
    cap >> src;
    // check if we succeeded
    if (src.empty()) {
        cerr << "ERROR! blank frame grabbed\n";
        return -1;
    }

    bool isColor = (src.type() == CV_8UC3);
    //--- INITIALIZE VIDEOWRITER
    VideoWriter writer;
    int codec = VideoWriter::fourcc('M', 'J', 'P', 'G');  // select desired codec (must be available at runtime)
    //int codec = VideoWriter::fourcc('Y', 'U', 'Y', 'V');  // select desired codec (must be available at runtime)
    double fps = 30.0;                          // framerate of the created video stream
//string filename = "./live.avi";             // name of the output video file
//string filename = "/mnt/usb1/output_0001.avi";             // name of the output video file 

	time(&now);
	getFileName(filename,now);
	
    writer.open(filename, codec, fps, {640,480}, 0);  //  0  means not color

    // check if we succeeded
    if (!writer.isOpened()) {
        cerr << "Could not open the output video file for write\n";
        return -1;
    }
    //--- GRAB AND WRITE LOOP
    cout << "Writing videofile: " << filename << endl;
    cv::Mat gray;
    //time_t epochTime = time(nullptr); 
    
    std::system("exec /home/larry/WiringPi/apeture &");   // 
    
    while (flag)    //   
    {
        // check if we succeeded
        if (!cap.read(src)) {
            cerr << "ERROR! frame grabbed\n";
            break;
        }
        cvtColor(src, gray, cv::COLOR_BGR2GRAY);
        // encode the frame into the videofile stream

        writer.write(gray);
        
        //imshow("Original", gray);

        if (waitKey(1) == 27) 
        {
            cout << "esc key is pressed by user" << endl;
            break;
        }
        
        
        frameCounter++;

    }
    
    digitalWrite(ledPin, LOW); // Turn LED on
    writer.release();
    
    //int elaspedTime = time(nullptr) - epochTime ;
    
    getTextFileName(filename,now);
	
    // Use the filename
    FILE *fp = fopen(filename, "w");
    if (fp != NULL) {
        fprintf(fp,"elasped seconds:  %d\n",duration);
        fprintf(fp,"Frames Recorded:  %d\n",frameCounter);
        fprintf(fp,"Frames per second:  %.2f\n",frameCounter/(float)duration);        
        fprintf(fp,"exec /home/larry/wittypi/run.sh  \n");
        fclose(fp);
    } else {
        printf("Error opening file.\n");
    }
    
    
    cout << "elasped seconds:   " << duration << endl;
    cout << "frames per second:   " << frameCounter/(float)duration << endl;

    std::system("exec sudo killall apeture  "); 
    
    std::system("exec /home/larry/wittypi/run.sh  "); //  execute this from bash

    
    return 0;
}
