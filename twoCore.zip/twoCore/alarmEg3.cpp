// g++ alarmEg.cpp -o alarmEg

#include <stdio.h>
#include <unistd.h>
#include <signal.h>

int flag = 1;

static void alarmHandler(int signo);

int main(void){

    alarm(12);

    signal(SIGALRM, alarmHandler);
    int i;
    while(flag){
        printf("%d\n", i);
        sleep(1); 
        i++;
    }

    return 0;

}

static void alarmHandler(int signo){
    flag = 0;
    printf("Alarm signal sent!,  flag:  %d, signo:  %d\n",flag,signo);

}
