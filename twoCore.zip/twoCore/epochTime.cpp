//      g++ epochTime.cpp -o epochTime 
#include <ctime>
#include <iostream>

int main() {
    
    std::time_t epochTime = std::time(nullptr);
    std::cout << "Current time: " << epochTime << " seconds since the Unix epoch" << std::endl;
    
    //time_t epochTime = 1674818720; // Replace with your epoch time value

    // Convert epoch time to local time
    struct tm *localTime = localtime(&epochTime);

    // Format the local time
    char buffer[80];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", localTime);

    // Print the formatted local time
    std::cout << "Local time: " << buffer << std::endl;

    return 0;
}
