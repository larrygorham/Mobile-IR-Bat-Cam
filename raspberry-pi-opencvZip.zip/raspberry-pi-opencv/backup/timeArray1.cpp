// C program to demonstrate the array within structures
//    g++ -std=c++11 -pthread timeArray.cpp
#include <string.h>
#include <stdio.h>
#include <time.h>

#define arraySize 16

// Defining array within and structure
typedef struct{
    int v0[arraySize] = {0};
    int v1[arraySize] = {0};
} Input_t ;

void changIt (Input_t* input); // function declaration

void delay_usec(int number_of_msecs)
{
    // Storing start time
    clock_t start_time = clock();

    // looping till required time is not achieved
    while (clock() < start_time + number_of_msecs);
}
int main()
{
    // Declares structure variable
    Input_t input;

    changIt (&input); // pass address of "input" to the function
    // printing the data
    int inc;
    for (inc = 0; inc < arraySize; inc++) {
        printf("%d ", input.v0[inc]);
    }
    printf("\n");
        for (inc = 0; inc < arraySize; inc++) {
        printf("%d ", input.v1[inc]);
    }
    printf("%d \n",clock());
    delay_usec(10000000);
    printf("%d \n",clock());
    return 0;
}

void changIt (Input_t* input)  // changIt definition
{
    for (int inc = 0; inc < arraySize; inc++) {
        input->v0[inc] =  inc;
        input->v1[inc] =  inc + arraySize;
    }
}


