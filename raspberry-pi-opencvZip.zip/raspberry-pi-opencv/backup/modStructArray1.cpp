// C program to demonstrate the array within structures
//    g++ -std=c++11 -pthread modStructArray.cpp
#include <string.h>
#include <stdio.h>

// Defining array within structure
struct Employee {

    // character array to store name of the employee
    char Name[20];
    int employeeID;
    // integer array to maintain the record of attendanc eof
    // the employee
    int WeekAttendence[7];
};

int main()
{
    // defining structure of type Employee
    struct Employee emp;

    // adding data
    emp.employeeID = 1;
    strcpy(emp.Name, "Rohit");
    int week;
    for (week = 0; week < 7; week++) {
        int attendence;
        emp.WeekAttendence[week] = week;
    }
    printf("\n");

    // printing the data
    printf("Emplyee ID: %d - Employee Name: %s\n",
           emp.employeeID, emp.Name);
    printf("Attendence\n");
    for (week = 0; week < 7; week++) {
        printf("%d ", emp.WeekAttendence[week]);
    }
    printf("\n");

    return 0;
}
