// C program to demonstrate the array within structures
//    g++ -std=c++11 -pthread twoCoreTemp.cpp
#include <stdio.h>
#include <time.h>

#define ARRAYSIZE 16
#define UPDATES 1
#define invert(r)  (r+1)%2

// Defining array within and structure
typedef struct{
    int v0[ARRAYSIZE] = {0};
    int v1[ARRAYSIZE] = {0};
    int flip = 0;
    int flop = 0;
} Input_t ;

void capture (Input_t* input); // function declaration

void delay_usec(int number_of_msecs)
{
    // Storing start time
    clock_t start_time = clock();

    // looping till required time is not achieved
    while (clock() < start_time + number_of_msecs);
}


void capture (Input_t* input)  // capture definition
{
  for (int iUpS = 0 ; iUpS <  UPDATES; iUpS++){

        while ( input->flip !=  input->flop){
            delay_usec(1);
        }
        printf(" capture flip = %d  flop = %d\n",input->flip,input->flop);
        if(input->flip == 0){
            for (int inc = 0; inc < ARRAYSIZE; inc++) {
                input->v0[inc] =  inc;
            }
        }else{
            for (int inc = 0; inc < ARRAYSIZE; inc++) {
                input->v1[inc] =  inc + ARRAYSIZE;
            }
        }

        input->flip = invert(input->flip);
        delay_usec(1e6);
    }

}

void record (Input_t* input)  // record definition
{
     for (int iUpS = 0 ; iUpS <  UPDATES; iUpS++){

        while ( input->flip ==  input->flop){
            delay_usec(1);
        }
        printf(" record flip = %d  flop = %d\n",input->flip,input->flop);
        if(input->flip == 0){
            for (int inc = 0; inc < ARRAYSIZE; inc++) {
                printf("%d ", input->v1[inc]);
            }
        }else{
            for (int inc = 0; inc < ARRAYSIZE; inc++) {
        printf("%d ", input->v0[inc]);
            }
        }

        input->flop = invert(input->flop);
    }
 
}

int main()
{
    // Declares structure variable
    Input_t input;
    
    printf("%d \n",clock());
    
    capture (&input); // pass address of "input" to the function
    
    printf("%d \n",clock());
    
    // printing the data
    int inc;
    printf("\n  v0 ");
    for (inc = 0; inc < ARRAYSIZE; inc++) {
        printf("%d ", input.v0[inc]);
    }
    printf("\n  v1 ");
    for (inc = 0; inc < ARRAYSIZE; inc++) {
        printf("%d ", input.v1[inc]);
    }
    //printf(" flip = %d\n",input.flip);

    return 0;
}

