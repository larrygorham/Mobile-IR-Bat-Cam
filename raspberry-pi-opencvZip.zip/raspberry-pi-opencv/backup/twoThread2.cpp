//  g++ -std=c++11 -pthread twoThread.cpp
#include <iostream>
#include <thread>


void call_from_thread0(int tid) {
   std::cout << "Launched by thread " << tid << std::endl;
}

void call_from_thread1(int tid) {
   std::cout << "Launched by thread " << tid << std::endl;
}
int main() {
  std::thread t[2];

  //Launch two threads
  t[0] = std::thread(call_from_thread0, 0);
  t[1] = std::thread(call_from_thread1, 1);


  //Join the threads with the main thread
  t[0].join();
  t[1].join();


  return 0;
}
