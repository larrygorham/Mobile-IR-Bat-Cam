// Parallel dot product implementation, example of race condition and use of an atomic type
//  g++ -std=c++11 -pthread twoCore3.cpp
#include <iostream>
#include <thread>
#include <vector>
#include <atomic>

//Split "mem" into "parts", e.g. if mem = 10 and parts = 4 you will have: 0,2,4,6,10
//if possible the function will split mem into equal chuncks, if not 
//the last chunck will be slightly larger



void dot_product(const std::vector<int> &v1, const std::vector<int> &v2, std::atomic<int> &result, int L, int R){
	int partial_sum = 0;
	for(int i = L; i < R; ++i){
		partial_sum += v1[i] * v2[i];
	}
	result += partial_sum;
}

int main(){
	int nr_elements = 100000;

	std::atomic<int> result(0);

	std::vector<std::thread> numVec;

	//Fill two vectors with some values 
	std::vector<int> v1(nr_elements,3), v2(nr_elements,2);

	
	//Launch 2 numVec:
	numVec.push_back(std::thread(dot_product, std::ref(v1), std::ref(v2), std::ref(result), 0,nr_elements/2));
	numVec.push_back(std::thread(dot_product, std::ref(v1), std::ref(v2), std::ref(result), nr_elements/2, nr_elements));


	//Join the threads with the main thread
	numVec[0].join();
	numVec[1].join();

    //Print the result
    std::cout<<result<<std::endl;

	return 0;
}
