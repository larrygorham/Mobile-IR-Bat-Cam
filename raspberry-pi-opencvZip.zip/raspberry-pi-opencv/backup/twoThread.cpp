//  g++ -std=c++11 -pthread twoThread.cpp
#include <iostream>
#include <thread>
#include <time.h>

void delay_usec(int number_of_usecs){
  // Storing start time
  clock_t start_time = clock();

  // looping till required time is not achieved
  while (clock() < start_time + number_of_usecs);
}

void call_from_thread0(int tid) {
  delay_usec(2e6);
  std::cout << "Launched by thread " << tid << std::endl;
}

void call_from_thread1(int tid) {
  delay_usec(1e6);
  std::cout << "Launched by thread " << tid << std::endl;
}
int main() {
  std::thread t0, t1;

  //Launch two threads
  t0 = std::thread(call_from_thread0, 0);
  t1 = std::thread(call_from_thread1, 1);


  //Join the threads with the main thread
  t0.join();
  t1.join();


  return 0;
}
