OpenCV 4 cross compiled for Raspberry Pi and BeagleBone Black. For more details check my articles: 

[Cross compiling OpenCV 4 for Raspberry Pi and BeagleBone Black](https://solarianprogrammer.com/2018/12/18/cross-compile-opencv-raspberry-pi-raspbian/).

[Cross compiling OpenCV 4 for Raspberry Pi Zero](https://solarianprogrammer.com/2019/08/07/cross-compile-opencv-raspberry-pi-zero-raspbian/).


You can get the binaries from [https://github.com/sol-prog/raspberry-pi-opencv/releases/](https://github.com/sol-prog/raspberry-pi-opencv/releases/)
