//   g++ camThread.cpp -o camThread `pkg-config --cflags --libs opencv4`

#include <opencv2/opencv.hpp>
#include <thread>
#include <mutex>

using namespace cv;
using namespace std;

class CameraThread {
public:
    CameraThread(int cameraIndex) : cameraIndex(cameraIndex), running(false) {}

    void start() {
        running = true;
        thread = std::thread(&CameraThread::run, this);
    }

    void stop() {
        running = false;
        thread.join();
    }

    Mat getFrame() {
        std::lock_guard<std::mutex> lock(frameMutex);
        return frame.clone();
    }

private:
    int cameraIndex;
    bool running;
    std::thread thread;
    Mat frame;
    std::mutex frameMutex;

    void run() {
        VideoCapture cap(cameraIndex);
        if (!cap.isOpened()) {
            cerr << "Error opening camera" << endl;
            return;
        }

        while (running) {
            Mat frameLocal;
            cap >> frameLocal;

            if (!frameLocal.empty()) {
                std::lock_guard<std::mutex> lock(frameMutex);
                frame = frameLocal.clone();
            }
        }
    }
};

int main() {
    CameraThread camera(0);
    camera.start();

    while (true) {
        Mat frame = camera.getFrame();

        if (!frame.empty()) {
            imshow("Camera", frame);
        }

        if (waitKey(1) == 27) {
            break;
        }
    }

    camera.stop();
    return 0;
}
