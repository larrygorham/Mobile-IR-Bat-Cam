//   g++ global2threads.cpp -o global2threads
#include <string>
#include <thread>
#include <mutex>
#include <iostream>
#include <stdio.h>
using namespace std;

std::string var = "foo";
// a global instance of std::mutex to protect global variable
std::mutex m;

// function to provide read and write access
// "protected" with mutex
std::string test(const std::string& value = ""){
    std::lock_guard<std::mutex> guard(m);
    if (value == "")
    {
        return var;
    }
    else
    {
        var = value;
        return "";
    }
}

void thread1(){
    std::lock_guard<std::mutex> guard(m);
    // use global variable local
    string localVar = test();
}
void thread2(){
    std::lock_guard<std::mutex> guard(m);
    // overwrite global variable
    test("bar");
}
void thread3(){
    std::lock_guard<std::mutex> guard(m);
    // use global variable local
    string localVar = test();
}

int main()
{    
    thread t1(thread1);
    thread t2(thread2);
    thread t3(thread3);

    t1.join();
    t2.join();
    t3.join();

    cout << "var  " << var  << endl;

    return 0;
}
