//     +++
//     g++ videoWriter_basic1.cpp -o test `pkg-config --cflags --libs opencv4`
//   This does everything but not at 30 fps for all cmeras
#include <opencv2/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <stdio.h>
#include <time.h>
#include <string.h>
using namespace cv;
using namespace std;

void getFileName(char tempFileName[30], const time_t &now)
{
    struct tm *timeinfo;
	
	timeinfo = localtime(&now);

    char buffer[80];


    // Format date and time (e.g., "20241228_092600")
    strftime(buffer, sizeof(buffer), "%Y%m%d_%H%M%S", timeinfo);


    // Create filename with date and time
    strcpy(tempFileName, "/media/larry/pro128e/WMCC_MYLU_");
    strcat(tempFileName, buffer);
    strcat(tempFileName, ".avi");

	return ;
}

int main(int, char**)
{

    time_t now;
    struct tm *timeinfo;
	char filename[100];


    Mat src;

    VideoCapture cap(0, CAP_V4L);  //  recommended when capturing a webcam
    // check if we succeeded
    if (!cap.isOpened()) {
        cerr << "ERROR! Unable to open camera\n";
        return -1;
    }
    cap.set(CAP_PROP_FRAME_WIDTH, 640);//Setting the width of the video   720
    cap.set(CAP_PROP_FRAME_HEIGHT, 480);//Setting the height of the video    480

    // get one frame from camera to know frame size and type
    cap >> src;
    // check if we succeeded
    if (src.empty()) {
        cerr << "ERROR! blank frame grabbed\n";
        return -1;
    }
    bool isColor = (src.type() == CV_8UC3);
    //--- INITIALIZE VIDEOWRITER
    VideoWriter writer;
    int codec = VideoWriter::fourcc('M', 'J', 'P', 'G');  // select desired codec (must be available at runtime)
    //int codec = VideoWriter::fourcc('Y', 'U', 'Y', 'V');  // select desired codec (must be available at runtime)
    double fps = 30.0;                          // framerate of the created video stream
//string filename = "./live.avi";             // name of the output video file
//string filename = "/media/larry/pro128e/output_0001.avi";             // name of the output video file 

	time(&now);
	getFileName(filename,now);
	
    writer.open(filename, codec, fps, {640,480}, 0);  //  0  means not color

    // check if we succeeded
    if (!writer.isOpened()) {
        cerr << "Could not open the output video file for write\n";
        return -1;
    }
    //--- GRAB AND WRITE LOOP
    cout << "Writing videofile: " << filename << endl;
    cv::Mat gray;
    for (int fn = 0;fn < 30*60;fn++)    //   120   gives 2 hr
    {
        // check if we succeeded
        if (!cap.read(src)) {
            cerr << "ERROR! blank frame grabbed\n";
            break;
        }
        cvtColor(src, gray, cv::COLOR_BGR2GRAY);
        // encode the frame into the videofile stream

        writer.write(gray);
        // show live and wait for a key with timeout long enough to show images
        //if (fn%30 == 29)
        imshow("Live", gray);
        if (waitKey(5) >= 0)
            break;

    }
    writer.release();
    return 0;
}
