#!/bin/bash


i=63

while [ $i -le 63 ]
do
v4l2-ctl --set-ctrl exposure_time_absolute=$i
echo $i 
sleep 5
i=$((i - 1))
done
