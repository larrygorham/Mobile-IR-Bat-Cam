//   g++ passMat.cpp -o out `pkg-config --cflags --libs opencv4`
//   g++ passMat.cpp -o passMat `pkg-config --cflags --libs opencv4`
#include <atomic>
#include <thread>
#include "opencv2/opencv.hpp"
#include <iostream>
#include <string>

using namespace std;
using namespace cv;

//Mat frame;

atomic_bool stop = ATOMIC_VAR_INIT(false);

void captureFrames(VideoCapture& cap, Mat& frame) {
    while (true) {
        cap >> frame;
        if (frame.empty()) {
            break;
        }
    }
}

int main() {
    VideoCapture cap(0, CAP_V4L); 
    if (!cap.isOpened()) {
        std::cerr << "Error opening video stream" << std::endl;
        return -1;
    }

    Mat frame;
    
    cout << "Capturing the video. Press Esc + enter to stop " << endl;
    
    std::thread captureThread(captureFrames, std::ref(cap), std::ref(frame));

    while (true) {
        if (!frame.empty()) {
            imshow("Live", frame);
        }
        char c = (char)waitKey(1);
        if (c == 27) {
            stop = true;
            break;
        }
    }

    captureThread.join();
    cap.release();
    destroyAllWindows();
    return 0;
}

