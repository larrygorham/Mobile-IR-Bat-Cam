#!/bin/bash

# This script   steam.sh 

i="0"
testVar="0"
# do it 10 times
#while [ $i -lt 10 ]
#do
#tail -n -1 steamInf.txt > testVar.txt
echo $[$i+1]  > testVar.txt
MY_NEW_VAR=$(cat  testVar.txt | sed -e 's/\r//g')
echo $i ${MY_NEW_VAR}
/home/pi/boot/recordH &
sleep  2
i=$[$i+1]
/home/pi/boot/steam 
echo $i ${MY_NEW_VAR}
#done





