 #!/bin/bash
i=1
while [ $i -le 9999 ]
do
	date >> panVolt.txt
	./panVolts >> panVolt.txt
i=$((i + 1))
done
