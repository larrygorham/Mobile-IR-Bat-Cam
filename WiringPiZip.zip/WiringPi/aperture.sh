#!/bin/bash

num=$1
#v4l2-ctl --set-ctrl exposure_time_absolute=$num
v4l2-ctl -c auto_exposure=1 
v4l2-ctl -c exposure_time_absolute=$num
