//  g++ int2bash.c -o int2bash 
#include <stdio.h>
#include <stdlib.h>

int main() {
    int num = 123;
    char command[50];
    sprintf(command, "./gotInt.sh %d", num);
    system(command);
    return 0;
}
