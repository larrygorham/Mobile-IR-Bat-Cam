// rp-mcp3008 Reads analogue values through MCP3008 chip
//  gcc apeture.cpp -o apeture -lwiringPi

//#include <math.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <wiringPi.h>
#include <mcp3004.h>
#include <wiringPiSPI.h>


#define numAverage  100

float lit;
int expos;

int main (int argc, char *argv[])
{
    FILE *fp;
	int i;
	float fract = 3.3/(float)(1024*numAverage);
	printf("wiringPiSPISetup RC=%d\n",wiringPiSPISetup(0,500000));
    fp = fopen("/home/larry/WiringPi/light.txt", "wa");
	mcp3004Setup(100,0);
	
	for (int frameCounter=1; frameCounter<216000 ; frameCounter++) {
		lit = .0;
		for(int j=0;j<numAverage;j++){

				lit += ((float) analogRead(102))*fract;
		}	
		usleep(27700);
		if (frameCounter % 30 == 0){
			expos = (int)  -13115.*lit*lit*lit*lit + 13718.*lit*lit*lit - 2967.*lit*lit + 299.7*lit - 10.;//10.  3.623 is +.5
			if (lit > .54)
				expos = 332;  //347
			char command[50];
			//std::system("exec /home/larry/wittypi/run.sh  "); 
            sprintf(command, "exec /home/larry/WiringPi/aperture.sh %d &", expos);
            //sprintf(command, "./aperture.sh %d &", expos);
            system(command);
			printf("%d %d  %.3f\n",expos,frameCounter,lit);
			fprintf(fp,"%d %d  %.3f\n",expos,frameCounter,lit);

		}
			
	}
			    fclose(fp);
}
