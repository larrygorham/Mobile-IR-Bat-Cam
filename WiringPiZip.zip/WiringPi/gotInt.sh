#!/bin/bash
# Bash script (gotInt.sh)
number=$1
echo "The number is: $number"
