g++ writeFile.c -o writeFile -lwiringPi
#include <iostream>
#include <fstream>
#include <iomanip>

int main() {
    float myFloat = 3.14159f;
    std::string filename = "float_data.txt";

    std::ofstream outputFile(filename);

    if (outputFile.is_open()) {
        outputFile << std::fixed << std::setprecision(6) << myFloat << std::endl;
        outputFile.close();
        std::cout << "Float value written to " << filename << std::endl;
    } else {
        std::cerr << "Unable to open file: " << filename << std::endl;
        return 1;
    }
    return 0;
}
