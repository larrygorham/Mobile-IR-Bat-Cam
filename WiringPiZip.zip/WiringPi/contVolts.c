// rp-mcp3008 Reads analogue values through MCP3008 chip
//  gcc contVolts.c -o contVolts -lwiringPi

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <wiringPi.h>
#include <mcp3004.h>
#include <wiringPiSPI.h>


#define BASE 100
#define SPI_CHAN 0
#define numAverage  10000

float aIn[8] = {0};
float cell[10] = {0};
float temp[8];
float fract[8];  //3.3/1024.

int main (int argc, char *argv[])
{
	int i,j,k;
	//float fract = 3.3/(float)(1024*numAverage);
	fract[0] = 3.3/(float)(1024*numAverage)*5.437;
	fract[1] = 3.3/(float)(1024*numAverage)*3.565;
	fract[2] = 3.3/(float)(1024*numAverage)*2.390;
	fract[3] = 3.3/(float)(1024*numAverage)*3.565;
	fract[4] = 3.3/(float)(1024*numAverage)*2.390;
	fract[5] = 3.3/(float)(1024*numAverage)*3.565;
	fract[6] = 3.3/(float)(1024*numAverage)*2.390;
	fract[7] = 3.3/(float)(1024*numAverage)*5.510;

	
	printf("wiringPiSPISetup RC=%d\n",wiringPiSPISetup(0,500000));

	mcp3004Setup(BASE,SPI_CHAN);
		
	// Loop indefinitely
	while(1){
		
		for(i=0;i<8;i++){
			aIn[i] = 0.;
		}
		
		for(j=0;j<numAverage;j++){
			for(i=0;i<8;i++){
				aIn[i] += ((float) analogRead(BASE+i))*fract[i];
			}
		}	
		cell[1] = aIn[0] - aIn[1];
		cell[2] = aIn[1] - aIn[2];
		cell[3] = aIn[2];
		cell[4] = aIn[0] - aIn[3];
		cell[5] = aIn[3] - aIn[4];
		cell[6] = aIn[4];
		cell[7] = aIn[0] - aIn[5];
		cell[8] = aIn[5] - aIn[6];
		cell[9] = aIn[6];
		cell[10] = aIn[7];
		
		float avgBatVolt = 0;
		printf("WittyPi voltage = %f\n",aIn[0]);
		for(i=1;i<10;i++){	
			printf("cell[%d] = %f\n",i,cell[i]);
		}
		printf("Charging Amps = %f\n",(aIn[0] - cell[10])/.186); //small resistor
		printf("\n");
	}
}
