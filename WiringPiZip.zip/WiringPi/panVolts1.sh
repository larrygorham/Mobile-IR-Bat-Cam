#!/bin/bash
i=1
while [ $i -le 9 ]
do
	date
	./panVolts
i=$((i + 1))
done
