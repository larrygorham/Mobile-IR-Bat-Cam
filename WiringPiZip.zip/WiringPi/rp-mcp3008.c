// rp-mcp3008 Reads analogue values through MCP3008 chip
//  gcc rp-mcp3008.c -o rp-mcp3008 -lwiringPi

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <wiringPi.h>
#include <mcp3004.h>
#include <wiringPiSPI.h>


#define BASE 100
#define SPI_CHAN 0
#define numAverage  100

float cell[8] = {0};
float temp[8];
float fract = 3.3/1024.;

int main (int argc, char *argv[])
{
	int i,j;
	float fract = 3.3/(float)(1024*numAverage);
	printf("wiringPiSPISetup RC=%d\n",wiringPiSPISetup(0,500000));

	mcp3004Setup(BASE,SPI_CHAN);
	
// Loop indefinitely, waiting for 100ms between each set of data
	for(j=0;j<numAverage;j++){
		for(i=0;i<8;i++){
			cell[i] += ((float) analogRead(BASE+i))*fract;
		}
	}	
	for(i=0;i<8;i++){	
		  printf("cell[%d] = %f\n",i,cell[i]);
	}
}
