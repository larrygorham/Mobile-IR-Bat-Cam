// rp-mcp3008 Reads analogue values through MCP3008 chip
//  gcc apeture.cpp -o apeture -lwiringPi

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <wiringPi.h>
#include <mcp3004.h>
#include <wiringPiSPI.h>


#define numAverage  100

float lit;

int main (int argc, char *argv[])
{
	int i;
	float fract = 3.3/(float)(1024*numAverage);
	printf("wiringPiSPISetup RC=%d\n",wiringPiSPISetup(0,500000));

	mcp3004Setup(100,0);
	
	for (int frameCounter=1; frameCounter<216000 ; frameCounter++) {
		lit = .0;
		for(int j=0;j<numAverage;j++){

				lit += ((float) analogRead(102))*fract;
		}	
		usleep(33333);
		if (frameCounter % 30 == 0)
			printf("%d %.3f\n",frameCounter,lit);
	}
}
