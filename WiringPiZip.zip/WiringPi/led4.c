//  gcc led4.c -o led4 -lwiringPi


#include <wiringPi.h>

//  pin # 16,   gpio23  is addressed as 4  ???

int main() {

    int ledPin = 4; // GPIO pin connected to LED (modify as needed)



    wiringPiSetup(); // Initialize wiringPi

    pinMode(ledPin, OUTPUT); // Set LED pin as output

while(1){

    digitalWrite(ledPin, HIGH); // Turn LED on
    delay(1000);

    digitalWrite(ledPin, LOW); // Turn LED off
    delay(1000);  

}


    return 0;

} 
