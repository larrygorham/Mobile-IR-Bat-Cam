 #!/bin/bash
i=1
while [ $i -le 99999 ]
do
	b=$(date +%s)
	printf "  %(%H %M %S)T"	   "$b" >> panVolt.txt
	a=$(./panVolts +%f)
	printf "  %.2f   \n" "$a" >> panVolt.txt

i=$((i + 1))
done

# a=$(./panVolts +%f)
# b=$(date +%s) && printf "  %(%H %M %S)T" "$b" && printf "  %.2f   \n" "$a"
