// gcc dt2epoch.c -o dt2epoch     //  -lwiringPi

#include <stdio.h> 
#include <string.h>
#include <time.h>

int main(void) {
    time_t epoch;
    char timeString[80] = { "04 03 2025 10 15 00" }; 
    struct tm my_tm;
    char buffer[80];

    memset(&my_tm, 0, sizeof(my_tm));
    if (sscanf(timeString, "%d %d %d %d %d %d", &my_tm.tm_mon, &my_tm.tm_mday, &my_tm.tm_year, &my_tm.tm_hour, &my_tm.tm_min, &my_tm.tm_sec) != 6)
    {
        /* ... error parsing ... */
        printf(" sscanf failed");
        return 1;
    }
    my_tm.tm_isdst = -1;
    my_tm.tm_year -= 1900;
    my_tm.tm_mon -= 1;

    epoch = mktime(&my_tm);
    if (epoch == -1) {
        printf("Error: unable to make time using mktime\n");
    }
    else {
        strftime(buffer, sizeof(buffer), "%c", &my_tm);
        printf("%s  (epoch=%ld)\n", buffer, (long)epoch);
    }

    return(0);
}
